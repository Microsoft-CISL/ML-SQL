﻿using System;
namespace HeartDiseaseDetection
{
    public interface SQLData
    {

        string GetHeader(string separator);


        string getData(string separator);


        string getMySQLData(string separator);


        string getSQLServerData(string separator);

    }
}
