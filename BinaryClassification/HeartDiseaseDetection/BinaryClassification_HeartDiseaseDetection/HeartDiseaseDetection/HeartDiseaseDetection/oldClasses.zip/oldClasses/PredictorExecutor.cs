﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.ML;
using MySql.Data.MySqlClient;
using QueryExecutor;

namespace HeartDiseaseDetection
{
    public class PredictorExecutor<T1, T2> where T1 : class,SQLData,new() where T2 : class,SQLData, new()
    {
        public PredictorExecutor()
        {
        }

        public void executePredictions(string Name, string modelPath, string inputSamplesFolder, string outputSamplesFolder, string resultFilePath, int[] chunckSizes, Tuple<string, string>[] Configurations, string tablename, string outputQuery, int nElements, char separator)
        {

            List<RunResult> runResults = new List<RunResult>();

            foreach (Tuple<string, string> configuration in Configurations)
            {

                string inputMode = configuration.Item1;
                string outputMode = configuration.Item2;




                List<string> results = new List<string>();

                Console.WriteLine("INPUT MODE: " + inputMode);
                Console.WriteLine("OUTPUT MODE: " + outputMode);


         

                foreach (int chunk in chunckSizes)
                {
                    Console.WriteLine("Chunck size: " + chunk);
                    RunResult r = runSinglePrediction(Name, modelPath, inputSamplesFolder + chunk + "/", chunk, outputSamplesFolder, inputMode, outputMode, tablename, outputQuery, nElements, separator, true);
                    runResults.Add(r);
                }


                Console.WriteLine("==============================================================================");
            }


            Console.WriteLine("\n\n\n\nResults: \n");

            foreach (RunResult r in runResults)
            {
                Console.WriteLine("==============================================================================");

                r.WriteResult();

                Console.WriteLine("==============================================================================");
            }


            writeRunResult(runResults, resultFilePath);
        }


        private void writeRunResult(List<RunResult> results, string path)
        {
            System.IO.StreamWriter file1 = new System.IO.StreamWriter(path, false);
            file1.WriteLine(RunResult.getHeader(","));
            foreach (RunResult r in results)
            {
                file1.WriteLine(r.GetLineCsv(","));
            }

        }


        private RunResult runSinglePrediction(string name, string modelPath, string inputFolderPath, int chunck, String outputPath, string inputMode, string outputMode, string tablename, string outputQuery, int nElements, char separator, bool singleMode)
        {


            // Read all files 

            var watch = System.Diagnostics.Stopwatch.StartNew();
            float timeWC = 0f;

            float timeWithConnection = 0f;
            float timeWithOutConnection = 0f;

            //string ConnectionStringMYSQL = "server=localhost;Uid=root;Pwd=19021990;Database=MLtoSQL";
            //string ConnectionStringSQLSERVER = "server=localhost;Uid=root;Pwd=19021990;Database=MLtoSQL";
            var mySQLConnection = new MySqlConnection(SQLConnections.MYSQLConnection);

            var sqlserverConnection = new SqlConnection(SQLConnections.SQLSERVERConnection);

            var mlContext = new MLContext();

            string outpath = outputPath;




            switch (inputMode)
            {

                case "CSV":

                    foreach (string file in Directory.EnumerateFiles(inputFolderPath, "*.csv"))
                    {

                        IDataView inputDataForPredictions = mlContext.Data.LoadFromTextFile<T1>(file, separatorChar: separator, hasHeader: false);
                        //var predictionEngine = mlContext.Model.CreatePredictionEngine<HeartData, HeartPrediction>(model);



                        bool exists = System.IO.Directory.Exists(outpath);

                        if (!exists)
                        {
                            System.IO.Directory.CreateDirectory(outpath);
                        }

                        // HERE OUTPUT RESULTS

                        RunResult r = OutputPrediction(mlContext, modelPath, name, outpath, outputQuery, chunck, inputDataForPredictions, outputMode, mySQLConnection, sqlserverConnection);
                        timeWithConnection += r.timeWithConnection;
                        timeWithOutConnection += r.timeWithOutConnection;

                    }



                    break;

                case "MYSQL":


                    for (int k = 1; k < nElements; k = k + chunck)
                    {

                        string q = "select * from " + tablename + " where Id >= " + k + " and Id < " + (k + chunck);

                        //Console.WriteLine("Query: " + q);

                        mySQLConnection.Open();
                        var watchWithOutConnection = System.Diagnostics.Stopwatch.StartNew();
                        MySqlCommand cmd1 = new MySqlCommand(q, mySQLConnection);
                        MySqlDataReader reader = cmd1.ExecuteReader();

                        List<T1> inputs = new List<T1>();
                        while (reader.Read())
                        {

                            //reader.ge

                            if (reader.HasRows)
                            {
                                //Console.WriteLine("r_" + reader.ToString());
                                T1 obs = new T1();
                                obs.ReadDataFromMYSQL(reader);
                                inputs.Add(obs);
                            }



                        }

                        watchWithOutConnection.Stop();

                        timeWC += watchWithOutConnection.ElapsedMilliseconds;

                        //Console.WriteLine("INPUTs Size: " + inputs.Count);


                        mySQLConnection.Close();
                        //Console.WriteLine
                        //    ("Number of elements reads from database: "+ inputs.Count);

                        if (inputs.Count > 0)
                        {
                            IDataView inputDataForPredictions = mlContext.Data.LoadFromEnumerable(inputs);

                            RunResult r = OutputPrediction(mlContext, modelPath, name, outpath, outputQuery, chunck, inputDataForPredictions, outputMode, mySQLConnection, sqlserverConnection);
                            timeWithConnection += r.timeWithConnection;
                            timeWithOutConnection += r.timeWithOutConnection;
                        }
                    }




                    break;


                case "SQLSERVER":


                    for (int k = 1; k < nElements; k = k + chunck)
                    {

                        string q = "select * from " + tablename + " where Id >= " + k + " and Id < " + (k + chunck);

                        //Console
                        //    .WriteLine("Query: "+ q);

                        sqlserverConnection.Open();
                        var watchWithOutConnection = System.Diagnostics.Stopwatch.StartNew();
                        SqlCommand cmd1 = new SqlCommand(q, sqlserverConnection);
                        SqlDataReader reader = cmd1.ExecuteReader();

                        List<T1> inputs = new List<T1>();
                        while (reader.Read())
                        {

                            //reader.ge
                            //Console.WriteLine("r_"+ reader.ToString());
                            T1 obs = new T1 ();
                            obs.ReadDataFromSQLServer(reader);
                            inputs.Add(obs);

                        }
                        watchWithOutConnection.Stop();

                        timeWC += watchWithOutConnection.ElapsedMilliseconds;
                        sqlserverConnection.Close();

                        //Console.WriteLine
                        //    ("Number of elements reads from database: "+ inputs.Count);

                        IDataView inputDataForPredictions = mlContext.Data.LoadFromEnumerable(inputs);

                        RunResult r = OutputPrediction(mlContext, modelPath, name, outpath, outputQuery, chunck, inputDataForPredictions, outputMode, mySQLConnection, sqlserverConnection);
                        timeWithConnection += r.timeWithConnection;
                        timeWithOutConnection += r.timeWithOutConnection;
                    }



                    break;


            }



            // Somme di tempi

            RunResult result = new RunResult(name, inputMode, outputMode, "ML.NET", chunck, timeWithOutConnection, timeWithConnection, nElements, "BATCH_MODE");

            watch.Stop();
            return result;
        }




        private RunResult OutputPrediction(MLContext mlContext, string modelPath, string name, string outpath, string outputQuery, int chunck, IDataView inputDataForPredictions, string outputMode, MySqlConnection mySQLConnection, SqlConnection sqlserverConnection)
        {

            int i = 0;
            int nElements = 0;
            float timeWithConnection = 0f;
            float timeWithoutConnection = 0f;
            System.IO.StreamWriter file1 = new System.IO.StreamWriter(outpath + "output_" + chunck + "_" + i + ".csv", false);

            var watchWithConnection = System.Diagnostics.Stopwatch.StartNew();
            var watchWithOutConnection = System.Diagnostics.Stopwatch.StartNew();

            ITransformer model = mlContext.Model.Load(modelPath, out var inputSchema);
            List<T1> transactions = mlContext.Data.CreateEnumerable<T1>(inputDataForPredictions, reuseRowObject: false).Take(chunck).ToList();
            var predictionEngine = mlContext.Model.CreatePredictionEngine<T1, T2>(model);
            string separator = "";

            string values = "";
            StringBuilder sb = new StringBuilder();
            transactions.ForEach
            (testData =>
            {


                nElements++;
                T2 t = predictionEngine.Predict(testData);
                String line = generateLineCSV(testData.getData(separator), t.getData(separator), separator
                    );

                if (outputMode.Equals("CSV"))
                {
                    file1.WriteLine(generateINSERTINTOLine(testData.getData(separator), t.getData(separator), separator));

                }
                else if (outputMode.Equals("CONSOLE"))
                {
                    Console.WriteLine(generateINSERTINTOLine(testData.getData(separator), t.getData(separator), separator));

                }
                else if (outputMode.Equals("NO_OUTPUT"))
                {
                    // DO NOTHING
                }
                else if (outputMode.Equals("MYSQL") || outputMode.Equals("SQLSERVER"))
                {
                    // Insert into the database                            
                    string ll = "(" + testData.getId() + "," + t.getScores(separator) + "),";
                    sb.Append(ll);

                }

            });

            if (outputMode.Equals("MYSQL"))
            {
                values = sb.ToString();
                values = values.Substring(0, values.Length - 1);
                values += ";";
                watchWithOutConnection.Stop();
                timeWithoutConnection += watchWithOutConnection.ElapsedMilliseconds;
                mySQLConnection.Open();


                watchWithOutConnection.Start();
                // string insert = "INSERT into heart_disease_detection_with_score_output (Id,Score ) VALUES ";
                string insert = outputQuery;
                insert += "" + values;

                //  string cmdText = generateINSERTINTOLine(testData.Id, t.getData(separator), separator);
                MySqlCommand cmd = new MySqlCommand(insert, mySQLConnection);

                cmd.ExecuteNonQuery();
                watchWithOutConnection.Stop();
                timeWithoutConnection += watchWithOutConnection.ElapsedMilliseconds;
                mySQLConnection.Close();
            }
            else if (outputMode.Equals("SQLSERVER"))
            {
                values = sb.ToString();
                values = values.Substring(0, values.Length - 1);
                values += ";";

                // string insert = "INSERT into heart_disease_detection_with_score_output (Id,Score ) VALUES ";
                string insert = outputQuery;
                insert += "" + values;

                watchWithOutConnection.Stop();
                timeWithoutConnection += watchWithOutConnection.ElapsedMilliseconds;
                sqlserverConnection.Open();

                SqlCommand command = new SqlCommand(insert, sqlserverConnection);
                //command.Parameters.AddWithValue("@tPatSName", "Your-Parm-Value");
                command.ExecuteNonQuery();
                watchWithOutConnection.Stop();
                timeWithoutConnection += watchWithOutConnection.ElapsedMilliseconds;
                sqlserverConnection.Close();
            }


            watchWithConnection.Stop();
            timeWithConnection += watchWithConnection.ElapsedMilliseconds;


            RunResult r = new RunResult(name, "", outputMode, "ML.NET", chunck, timeWithoutConnection, timeWithConnection, nElements, "BATCH");


            return r;

        }


        private  string generateHeader(List<string> headers, string separator)
        {
            String line = "";
            foreach (string header in headers)
            {
                line += header + separator;
            }
            line = line.Substring(0, line.Length - separator.Length);

            return line;

        }


        private  string generateLineCSV(string data, string prediction, string separator)
        {
            String line = "";

            line += data;
            line += separator;
            line += prediction;


            return line;
        }


        private  string generateINSERTINTOLine(string data, string prediction, string separator)
        {
            String line = "(";

            line += data;
            line += separator;
            line += prediction;


            line += ")";

            return line;
        }



    }
}
