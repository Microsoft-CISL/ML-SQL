﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using Microsoft.ML.Trainers.FastTree;

namespace CreditCardFraudDetection.Trainer
{
    public class MLSQL
    {
        public MLSQL()
        {
        }


        public static string GenerateSQLQueriesOnDifferentModes(string query, string databaseName, string outputDatabaseName, string procedureName, string idParams, int mode, bool includeWhereClause)
        {
            string outputMode = "";


            string q = " select * from (" + query + " ) AS F;";

            switch (mode)
            {
                case 0:


                    break;
                //File output
                case 1:

                    q = query + " INTO OUTFILE \'/var/lib/mysql-files/test.csv\' \n FIELDS TERMINATED BY \',\' ENCLOSED BY \'\"\' LINES TERMINATED BY \'\n"; 



                    break;
                //Output
                case 2:

                    outputMode = "";
                    q = " select count(1) from (" + query + " ) AS F;";
                    break;
                //No output
                case 3:
                    outputMode = "insert into " + outputDatabaseName + " \n";
                    //Database
                    break;
            }





            string whereClause = "\n where Id >= @id  and Id < ( @id + chuncksize ); \n";

            if (!includeWhereClause)
            {
                whereClause = "";
            }




            return outputMode + q + whereClause;

        }

        public static void WriteSQL(string query, string outputPath)
        {
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(outputPath, false))
            {
                file.WriteLine(query);
            }
        }

        public static string generateLineCSV(string data, string prediction, string separator)
        {
            String line = "";

            line += data;
            line += separator;
            line += prediction;


            return line;
        }


        public static string generateINSERTINTOLine(string data, string prediction, string separator)
        {
            String line = "(";

            line += data;
            line += separator;
            line += prediction;


            line += ")";

            return line;
        }

        public static string GenerateSQLProcededure(string query, string databaseName,string outputDatabaseName,string procedureName, string idParams, int mode)
        {


            string init = "delimiter //\nset names utf8;\ndrop procedure if exists "+databaseName+"."+procedureName+";\n";


            string middle = "CREATE procedure "+databaseName+"."+procedureName+"(num INT, chuncksize INT)\nwholeblock:BEGIN\nSET @id = 1;\nWHILE @id <= num DO\n";

            string outputMode = "";
           

             string q = " select * from (" + query + " ) AS F";

            switch (mode)
            {
                case 0:


                    break;
                    //File output
                case 1:


                    break;
                    //Output
                case 2:

                    outputMode = "";
                    q = " select count(1) from (" + query + " ) AS F";
                    break;
                    //No output
                case 3:
                    outputMode = "insert into " +outputDatabaseName+" \n" ;
                    //Database
                    break;
            }





            string whereClause = "\n where Id >= @id  and Id < ( @id + chuncksize ); \n";

            string end = "\nSET @id = @id + chuncksize;\n  END WHILE;\nEND//";


            return init + middle + outputMode + q + whereClause + end;

        }



       
        public static void JoinTrainAndTest(String path1, String path2, String outputFile, bool header)
        {
            string[] lines1 = System.IO.File.ReadAllLines(path1);
            string[] lines2 = System.IO.File.ReadAllLines(path2);

            int i = 0;

            if (header)
            {
                i = 1;
            }


            using (System.IO.StreamWriter file = new System.IO.StreamWriter(outputFile, false))
            {

                for (int j = i; j < lines1.Length; j++)
                {
                    file.WriteLine(lines1[j]);
                }


                for (int j = i; j < lines2.Length; j++)
                {
                    file.WriteLine(lines2[j]);
                }

            }

            Console.WriteLine("End of the join process.");


           
        }





        public static int insertUniqueId(String inputFilePath, String outputFilePath, bool header, string separator, int start_id)
        {
            string[] lines = System.IO.File.ReadAllLines(inputFilePath);

            List<string> outputLines = new List<string>();

            int index = 0;
            if (header)
            {
                index = 1;
                outputLines.Add(lines[0] + separator +"Id");
            }


            for(int i = index; i< lines.Length; i++)
            {
                outputLines.Add(lines[i]+""+separator+""+start_id);
                start_id += 1;
            }

            using (System.IO.StreamWriter file = new System.IO.StreamWriter(outputFilePath, false))
            {

                for (int j = 0; j < outputLines.Count; j++)
                {
                    file.WriteLine(outputLines.ElementAt(j));
                }

            }

            Console.WriteLine("Start ID: "+start_id);

            return start_id;

        }

       
        public static void createDataSample(String inputPathDataset, String outputFolderPath, int [] chunckSizes, bool header)
        {

            //List<string> lines = new List<string>();

            // read all lines

            string[] lines = System.IO.File.ReadAllLines(inputPathDataset);


            Console.WriteLine("Number of lines: "+ lines.Length);

            int i = 0;
            String headerString = "";
            if (header)
            {
                i = 1;
                headerString = lines.ElementAt(0);
            }

            foreach (int chunkSize in chunckSizes)
            {
                for (int k = i; k < lines.Length; k = k + chunkSize)
                {

                    int index2 = k + chunkSize;

                    if (index2 > lines.Length)
                    {
                        index2 = lines.Length - 1;
                    }
                    string outputPath = outputFolderPath + "" + chunkSize + "/" ;
                    string filename = "sample_" + k + "_" + index2 + ".csv";
                    Console.WriteLine("outputPath: " + outputPath);

                    bool exists = System.IO.Directory.Exists(outputPath);

                    if (!exists)
                    {
                        System.IO.Directory.CreateDirectory(outputPath);
                    }
                    else
                    {
                    }
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(outputPath+filename,false))
                    {
                        if (header)
                        {
                            file.WriteLine(headerString);
                        }
                        for (int j= k; j< index2; j++)
                        {

                            file.WriteLine(lines[j]);

                        }


                    }



                    
                }
            }

        }




        public static string printPaths(int node, RegressionTree tree, double treeWeight, string[] featureColumnNames)
        {
            int[] path = new int[1000];

            ImmutableArray<double> leafValues = (System.Collections.Immutable.ImmutableArray<double>)tree.LeafValues;

            ImmutableArray<int> leftChild = (System.Collections.Immutable.ImmutableArray<int>)tree.LeftChild;
            ImmutableArray<int> rightChild = (System.Collections.Immutable.ImmutableArray<int>)tree.RightChild;

            ImmutableArray<int> numericalSplitFeatureIndexes = (System.Collections.Immutable.ImmutableArray<int>)tree.NumericalSplitFeatureIndexes;

            ImmutableArray<float> numericalSplitThreshold = (System.Collections.Immutable.ImmutableArray<float>)tree.NumericalSplitThresholds;
            ImmutableArray<bool> categoricalSplit = (System.Collections.Immutable.ImmutableArray<bool>)tree.CategoricalSplitFlags;



            List<int[]> paths = new List<int[]>();

            printPathsRecur(node, path, 0, tree, paths);

            Console.WriteLine("Stored path: ");
            foreach (int[] p in paths)
            {
                for (int w = 0; w < p.Length; w++)
                {
                    Console.Write(p[w] + " ");
                }
                Console.WriteLine(" ");
            }






            bool debug = false;
            String sql = "CASE ";
            foreach (int[] p in paths)
            {
                sql += "WHEN ";
                for (int w = 0; w < p.Length - 1; w++)
                {
                    int index = p[w];
                    int index_2 = p[w + 1];

                    if (debug)

                    {
                        Console.WriteLine("\n----------------------------------------------");
                        Console.WriteLine("Index: " + index);
                        Console.WriteLine("Index2 : " + index_2);
                    }

                    string feature = featureColumnNames[numericalSplitFeatureIndexes[index]];
                    float numericalsplit = numericalSplitThreshold[index];

                    if (debug)
                    {
                        Console.WriteLine("Feature " + feature);
                        Console.WriteLine("numverical split : " + numericalsplit);
                    }

                    bool left = false;
                    if (leftChild[index].Equals(index_2))
                    {
                        left = true;

                    }
                    else if (rightChild[index].Equals(index_2))
                    {
                        left = false;
                    }
                    else
                    {
                        throw new Exception("Error");
                    }


                    if (debug)
                    {
                        Console.WriteLine("LEFT CONDITION: " + left);
                        Console.WriteLine("LEFT : " + leftChild[index]);
                        Console.WriteLine("RIGHT : " + rightChild[index]);
                    }


                    string oper = " < ";

                    if (!left)
                    {
                        oper = " > ";
                    }

                    string featureString = feature;

                    sql += featureString + oper + numericalsplit;




                    if (index_2 < 0)
                    {
                        sql += " then " + leafValues[~index_2] + " * " + treeWeight + " ";
                    }
                    else
                    {
                        sql += " and ";
                    }

                }
                Console.WriteLine("SQL:  " + sql);

            }

            return sql;



        }

        public static string GenerateSQLNormalizeByVarianceColumns(string[] columns, string[] selectParams, float[] avgs, float[] stds, string suffix, string tableName)
        {

            string query = "select ";
            for (int i = 0; i < columns.Length; i++)
            {
                String c = columns[i];
                query += "(" + c + " - " + avgs[i] + ")* 1.0 * (" + stds[i] + ")  as " + c + suffix + " ,";
            }

            for (int i = 0; i < selectParams.Length; i++)
            {
                query += selectParams[i] + ",";
            }

            query = query.Substring(0, query.Length - 1);

            Console.WriteLine("QUERY: " + query + "\n\n");

            query += " from " + tableName;

            Console.WriteLine("QUERY: " + query + "\n\n");

            return query;
        }



        public static string GenerateSQLMultiplyByLinearCombination(string[] columns,string [] selectParams,float[] weights, string suffix, string tableName)
        {
            string query = "select ";
            for (int i = 0; i < columns.Length; i++)
            {
                String c = columns[i];
                query += "(" + c + " * " + weights[i] + " )  as " + c + suffix + " ,";
            }
            for (int i = 0; i < selectParams.Length; i++)
            {
                query += selectParams[i] + ",";
            }

            query = query.Substring(0, query.Length - 1);

            Console.WriteLine("QUERY: " + query + "\n\n");

            query += " from " + tableName;

            return query;
        }





        public static string GenerateSQLRegressionTree(string[] columns, string[] selectParams, string suffix, string tableName, List<double> treeWeights, List<RegressionTree> trees)
        {

            string query = "select ";

           

            for (int i = 0; i < trees.Count(); i++)
            {

                double treeWeight = treeWeights[i];
                RegressionTree tree = trees.ElementAt(i);




                String sqlCase = printPaths(0, tree, treeWeight, columns);
                sqlCase += "END AS tree_" + i + ",";

                query += sqlCase;


            }




           //query = query.Substring(0, query.Length - 1);

            for (int i =0;i<selectParams.Length;i++)
            {
                query += selectParams[i] + ",";
            }




            query = query.Substring(0, query.Length - 1);



            query += " from " + tableName;


           

            string s = " select (";

            for (int i = 0; i < trees.Count(); i++)
            {
               s+= "tree_" + i + "+";
            }
            s = s.Substring(0,s.Length-1);
            s += ") AS PredictedScore,";

            
            for (int i = 0; i < selectParams.Length; i++)
            {
                s += selectParams[i] + ",";
            }


            s = s.Substring(0, s.Length - 1);
            

            string externalQuery =s + " from (" +query+" ) AS F";






            return externalQuery;
        }

        public static void printPathsRecur(int node, int[] path, int pathLen, RegressionTree tree, List<int[]> paths)
        {


            /* append this node to the path array */
            path[pathLen] = node;
            pathLen++;

            /* it's a leaf, so print the path that led to here  */
            if (node < 0)
            {
                printArray(path, pathLen, paths);

            }
            else
            {
                /* otherwise try both subtrees */

                int left = tree.LeftChild[node];
                int right = tree.RightChild[node];


                printPathsRecur(left, path, pathLen, tree, paths);
                printPathsRecur(right, path, pathLen, tree, paths);
            }
        }


        public static void printArray(int[] ints, int len, List<int[]> paths)
        {
            int[] copy = new int[len];
            int i;
            for (i = 0; i < len; i++)
            {
                Console.Write(ints[i] + " ");
                copy[i] = ints[i];
            }
            Console.WriteLine("");
            paths.Add(copy);
        }







    }
}
