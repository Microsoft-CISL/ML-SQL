﻿using System;
namespace HeartDiseaseDetection
{
    public static class SQLConnections
    {
        public static string MYSQLConnection = "server=localhost;Uid=root;Pwd=19021990;Database=MLtoSQL";
        public static string SQLSERVERConnection = "server=localhost;Uid=root;Pwd=19021990;Database=MLtoSQL";
    }
}
